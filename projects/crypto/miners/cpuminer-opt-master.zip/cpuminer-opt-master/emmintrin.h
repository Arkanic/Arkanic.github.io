#if !defined(__arm__)
#include "SSE2NEON.h"
#endif