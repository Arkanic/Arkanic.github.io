#define insecure_memzero(buf, len) /* empty */
